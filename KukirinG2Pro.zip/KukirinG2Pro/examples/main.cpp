#include <Arduino.h>
#include "KukirinG2Pro.h"

// Erstellen Sie eine Instanz der Controller-Bibliothek
KukirinG2Pro controller;

// --- Hardware-Konfiguration ---
// ESP32 D1 Mini - Pins für Serial2
// Display TX (Grün)  → GPIO16 (RX2)
// Display RX (Gelb)  → GPIO17 (TX2)
#define DISPLAY_SERIAL Serial2
#define DEBUG_SERIAL Serial

// --- Modus-Auswahl ---
// Setzen Sie dies auf 'true', um die Geschwindigkeit basierend auf dem Gashebel zu simulieren.
// Setzen Sie dies auf 'false', um die Geschwindigkeit von einem externen "Sensor" zu verwenden.
const bool SIMULATE_SPEED_FROM_THROTTLE = true;

void setup() {
  DEBUG_SERIAL.begin(115200);
  while (!DEBUG_SERIAL) {
    ; // Warten auf die serielle Verbindung
  }
  DEBUG_SERIAL.println("Kukirin G2 Pro Library - Beispiel");

  // Initialisieren Sie die Bibliothek mit dem seriellen Port des Displays
  // und dem seriellen Port für das Debugging.
  controller.begin(DISPLAY_SERIAL, DEBUG_SERIAL);

  if (SIMULATE_SPEED_FROM_THROTTLE) {
    controller.useThrottleSimulation();
    DEBUG_SERIAL.println("Modus: Geschwindigkeit wird vom Gashebel simuliert.");
  } else {
    // Wenn die Simulation nicht verwendet wird, müssen wir keine spezielle
    // Funktion aufrufen. Wir übergeben die Geschwindigkeit einfach manuell
    // in der loop() mit controller.setSpeedRaw().
    DEBUG_SERIAL.println("Modus: Geschwindigkeit wird extern über setSpeedRaw() gesteuert.");
  }
}

void loop() {
  // Diese eine Zeile erledigt die gesamte UART-Kommunikation!
  // Sie gibt 'true' zurück, wenn ein neues Paket vom Display verarbeitet wurde.
  if (controller.update()) {
    
    // Dieser Block wird immer dann ausgeführt, wenn ein neues Paket vom Display ankommt.
    // Hier können Sie auf Display-Eingaben reagieren.
    
    // Beispiel: Eine Aktion auslösen, wenn die Hupe betätigt wird
    if (controller.isHornOn()) {
      DEBUG_SERIAL.println(">>> Hupen-Aktion hier auslösen! <<<");
    }
  }

  // Dieser Teil des Codes wird kontinuierlich ausgeführt, unabhängig von den Display-Paketen.
  // Hier ist der perfekte Ort, um externe Sensordaten zu verarbeiten und zu senden.

  if (!SIMULATE_SPEED_FROM_THROTTLE) {
    // --- Beispiel für die Verwendung eines externen Geschwindigkeitssensors ---

    // 1. Lesen Sie hier Ihren echten Sensor aus (z.B. Hall-Sensor, GPS, etc.).
    // Für dieses Beispiel simulieren wir einen Sensor, der die Geschwindigkeit
    // langsam ansteigen und dann wieder abfallen lässt.
    // Die Formel `(sin(millis() / 2000.0) + 1) / 2` erzeugt eine weiche Welle zwischen 0.0 und 1.0.
    float simulatedSensorPercentage = (sin(millis() / 2000.0) + 1) / 2.0;

    // 2. Konvertieren Sie den Messwert in den benötigten `speedRaw`-Wert.
    // Der Bereich geht von 0x0DAC (3500, Stillstand) bis ca. 0x0030 (48, V-Max).
    // Wir mappen unseren Sensorwert auf diesen Bereich.
    const uint16_t minSpeedRaw = 0x0030;
    const uint16_t maxSpeedRaw = 0x0DAC;
    uint16_t currentSpeedRaw = maxSpeedRaw - (simulatedSensorPercentage * (maxSpeedRaw - minSpeedRaw));
    
    // Wichtig: Bei 0 km/h muss der Wert genau 0x0DAC sein.
    if (simulatedSensorPercentage < 0.01) {
      currentSpeedRaw = maxSpeedRaw;
    }

    // 3. Übergeben Sie den berechneten Wert an die Bibliothek.
    // Die Bibliothek kümmert sich ab jetzt automatisch um die korrekte Übertragung an das Display.
    controller.setSpeedRaw(currentSpeedRaw);
  }
}

