/*
 * KukirinG2Pro.h - Arduino library for Kukirin G2 Pro display communication.
 * Created by Your Name, 2025.
 * Released into the public domain.
 */
#ifndef KukirinG2Pro_h
#define KukirinG2Pro_h

#include "Arduino.h"

// TX Packet (Display -> Controller, 20 Bytes)
// Note: __attribute__((packed)) is important for some compilers to prevent padding
struct __attribute__((packed)) TXPacket {
    uint8_t  startMarker;
    uint8_t  packetLength;
    uint8_t  commandType;
    uint8_t  subCommand;
    uint8_t  driveMode;
    uint8_t  functionBitmask;
    uint8_t  poleCount_L;
    uint8_t  poleCount_H;
    uint8_t  wheelCirc_L;
    uint8_t  wheelCirc_H;
    uint8_t  recupAccByte;
    uint8_t  reserved_0x0B;
    uint8_t  speedProfile_L;
    uint8_t  speedProfile_H;
    uint8_t  batteryConfig_L;
    uint8_t  batteryConfig_H;
    uint8_t  throttle_H;
    uint8_t  throttle_L;
    uint8_t  indicator_L;
    uint8_t  indicator_H;
};

// Decoded settings from the display
struct DecodedSettings {
    uint8_t rekupLevel;
    uint8_t accLevel;
    uint16_t poleCount;
    uint8_t wheelInches;
    uint8_t batteryVolts;
};

class KukirinG2Pro
{
  public:
    KukirinG2Pro();
    void begin(HardwareSerial& port, Stream& debugPort);
    void begin(HardwareSerial& port);
    bool update(); // Muss in der Haupt-loop() aufgerufen werden

    // --- Neue Methoden für die Geschwindigkeitssteuerung ---
    void setSpeedRaw(uint16_t speedRaw); // Überschreibt die Simulation mit einem externen Wert
    void useThrottleSimulation();        // Kehrt zur internen Gashebel-Simulation zurück

    // --- Getter für Echtzeitdaten ---
    uint16_t getThrottle();
    bool isBrakeActive();
    bool isLightOn();
    bool isHornOn();
    bool isBlinkerLeftOn();
    bool isBlinkerRightOn();
    
    // --- Getter für dekodierte Werte ---
    const DecodedSettings& getSettings();
    const TXPacket& getRawTXPacket(); // Für fortgeschrittene Nutzung

  private:
    // --- Interne Methoden ---
    void _handleDisplayPacket();
    void _sendResponse();
    void _printParsedData();
    DecodedSettings _decodeTxPacket(const TXPacket& packet);
    uint16_t _calculateSpeedRawFromThrottle(const TXPacket& packet);
    uint8_t _calculateSpeedChecksum(uint8_t speed_H, uint8_t speed_L);

    // --- Interne Variablen ---
    HardwareSerial* _serialPort;
    Stream* _debugPort;
    bool _debugEnabled = false;

    // RX/TX Buffer und Zustandsvariablen
    uint8_t _rxBuffer[sizeof(TXPacket)];
    uint8_t _rxIndex = 0;
    unsigned long _lastByteReceivedTime = 0;
    unsigned long _packetCounter = 0;
    
    TXPacket _txPacket;
    TXPacket _lastTxPacket;
    DecodedSettings _decodedSettings;

    // --- Neue Variablen für die Geschwindigkeitssteuerung ---
    bool _useExternalSpeed = false;
    uint16_t _externalSpeedRaw = 0;
};

#endif

